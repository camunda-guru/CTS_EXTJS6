﻿Ext.define('ChartsDemo.view.main.Pareto', {
    extend: 'Ext.Panel',
    requires: ['Ext.chart.theme.Category2',
    'ChartsDemo.store.Pareto',
    'Ext.chart.axis.Numeric',
    'Ext.chart.axis.Category',
    'Ext.chart.series.Bar',
    'Ext.chart.interactions.ItemHighlight',
     'Ext.chart.series.Line',
     'ChartsDemo.view.main.ParetoController'
    ],
    xtype: 'combination-pareto',
    controller: 'combination-pareto',

    width: 850,

    dockedItems: [{
        xtype: 'toolbar',
        dock: 'top',
        items: [
            '->',
            {
                text: Ext.os.is.Desktop ? 'Download' : 'Preview',
                handler: 'onDownload'
            }]
    }],

    items: [{
        xtype: 'cartesian',
        reference: 'chart',
        theme: 'category2',
        width: '100%',
        height: 500,
        store: {
            type: 'pareto'
        },
        insetPadding: '40 40 20 40',
        legend: {
            docked: 'bottom'
        },
        sprites: [{
            type: 'text',
            text: 'Restaurant Complaints by Reported Cause',
            fontSize: 22,
            width: 100,
            height: 30,
            x: 40, // the sprite x position
            y: 20  // the sprite y position
        }, {
            type: 'text',
            text: 'Data: Restaurant Complaints',
            font: '10px Helvetica',
            x: 12,
            y: 480
        }],
        axes: [{
            type: 'numeric',
            position: 'left',
            fields: ['count'],
            majorTickSteps: 10,
            reconcileRange: true,
            grid: true,
            minimum: 0
        }, {
            type: 'category',
            position: 'bottom',
            fields: 'complaint',
            label: {
                rotate: {
                    degrees: -45
                }
            }
        }, {
            type: 'numeric',
            position: 'right',
            fields: ['cumnumber'],
            reconcileRange: true,
            majorTickSteps: 10,
            renderer: 'onAxisLabelRender'
        }],
        series: [{
            type: 'bar',
            title: 'Causes',
            xField: 'complaint',
            yField: 'count',
            style: {
                opacity: 0.80
            },
            highlight: {
                fillStyle: 'rgba(204, 230, 73, 1.0)',
                strokeStyle: 'black'
            },
            tooltip: {
                trackMouse: true,
                renderer: 'onBarSeriesTooltipRender'
            }
        }, {
            type: 'line',
            title: 'Cumulative %',
            xField: 'complaint',
            yField: 'cumnumber',
            style: {
                lineWidth: 2,
                opacity: 0.80
            },
            marker: {
                type:'arrow',
                fx: {
                    duration: 200
                }
            },
            highlightCfg: {
                scaling: 2,
                rotationRads: Math.PI / 4
            },
            tooltip: {
                trackMouse: true,
                renderer: 'onLineSeriesTooltipRender'
            }
        }]
    }]

});