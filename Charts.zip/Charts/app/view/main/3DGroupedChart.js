﻿Ext.define('ChartsDemo.view.main.Grouped', {
    extend: 'Ext.Panel',
    xtype: 'column-grouped-3d',
    requires: [
         'Ext.chart.theme.Muted',
    'ChartsDemo.view.main.store.Earnings',
    'Ext.chart.interactions.ItemHighlight',    
 'Ext.chart.theme.Blue',
 'Ext.chart.theme.Purple',
    'Ext.chart.axis.Category3D',
    'Ext.chart.grid.VerticalGrid3D',
    'Ext.chart.series.Bar3D'
       ],
    controller: 'column-grouped-3d',
    width: 650,

    items: [{
        xtype: 'cartesian',
        width: '100%',
        height: 400,
        theme: 'muted',
        insetPadding: '70 40 0 40',
        interactions: ['itemhighlight'],
        animation: {
            duration: 500
        },
        store: {
            type: 'earnings'
        },
        legend: true,
        sprites: [{
            type: 'text',
            text: 'Profit and  Loss',
            textAlign: 'center',
            fontSize: 18,
            fontWeight: 'bold',
            width: 100,
            height: 30,
            x: 325, // the sprite x position
            y: 30  // the sprite y position
        }, {
            type: 'text',
            text: 'Quarter-wise comparison',
            textAlign: 'center',
            fontSize: 16,
            x: 325,
            y: 50
        }, ],
        axes: [{
            type: 'numeric3d',
            position: 'left',
            fields: ['consumer', 'corporate'],
            grid: true,
            title: 'Sales in USD',
            renderer: 'onAxisLabelRender'
        }, {
            type: 'category3d',
            position: 'bottom',
            fields: 'quarter',
            title: {
                text: 'Quarter',
                translationX: -30
                //css3 transformations --scale,translate,rotate,squeeze
            },
            grid: true,
            label: {
                rotate: {
                    degrees: -45
                }
            }
        }],
        series: {
            type: 'bar3d',
            stacked: false,
            title: ['consumer', 'corporate'],
            xField: 'quarter',
            yField: ['consumer', 'corporate'],
            label: {
                field: ['consumer', 'corporate'],
                display: 'insideEnd',
                renderer: 'onSeriesLabelRender'
            },
            highlight: true,
            style: {
                inGroupGapWidth: -7
            }
        }
    }]

});