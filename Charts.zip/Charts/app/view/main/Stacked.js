﻿Ext.define('ChartsDemo.view.main.Stacked100', {
    extend: 'Ext.Panel',
    xtype: 'column-stacked-100-3d',
    requires: ['Ext.chart.theme.Muted',
    'ChartsDemo.view.main.store.Earnings',
    'Ext.chart.interactions.ItemHighlight',
 'Ext.chart.theme.Blue',
 'Ext.chart.theme.Purple',
    'Ext.chart.axis.Category3D',
    'Ext.chart.grid.VerticalGrid3D',
    'Ext.chart.series.Bar3D'],
    controller: 'column-stacked-100-3d',
    width: 650,

    items: [{
        xtype: 'cartesian',
        reference: 'chart',
        interactions: ['itemhighlight'],
        width: '100%',
        height: 460,
        insetPadding: 40,
        innerPadding: '0 3 0 0',
        theme: 'Muted',
        legend: {
            docked: 'bottom'
        },
        store: {
            type: 'earnings'
        },
        animation: Ext.isIE8 ? false : {
            easing: 'backOut',
            duration: 500
        },
        axes: [{
            type: 'numeric3d',
            position: 'left',
            grid: true,
            fields: ['gaming', 'consumer', 'corporate', 'phone'],
            renderer: 'onAxisLabelRender',
            minimum: 0,
            maximum: 100
        }, {
            type: 'category3d',
            position: 'bottom',
            grid: true,
            fields: ['quarter'],
            label: {
                rotate: {
                    degrees: -45
                }
            }
        }],
        series: [{
            type: 'bar3d',
            fullStack: true,
            title: ['gaming', 'consumer', 'corporate', 'phone'],
            xField: 'quarter',
            yField: ['gaming', 'consumer', 'corporate', 'phone'],
            stacked: true,
            highlightCfg: {
                brightnessFactor: 1.2,
                saturationFactor: 1.5
            },
            tooltip: {
                trackMouse: true,
                renderer: 'onTooltipRender'
            }
        }],
        sprites: [{
            type: 'text',
            text: 'Usage share of desktop browsers',
            fontSize: 22,
            width: 100,
            height: 30,
            x: 40, // the sprite x position
            y: 20  // the sprite y position
        }, {
            type: 'text',
            text: 'Data: Browser Stats 2012',
            fontSize: 10,
            x: 12,
            y: 380
        }]
    }],

    tbar: [
        '->',
        {
            text: 'Preview',
            handler: 'onPreview'
        }
    ]
});