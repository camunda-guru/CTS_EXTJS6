﻿

var employee = Ext.create('GridModern.model.Employee')

Ext.define('GridModern.view.main.BigData', {
    extend: 'Ext.grid.Grid',
    requires: [
        'Ext.grid.plugin.Editable',
        'Ext.grid.plugin.ViewOptions',
        'Ext.grid.plugin.PagingToolbar',
        'Ext.grid.plugin.SummaryRow',
        'Ext.grid.plugin.ColumnResizing',
        'Ext.grid.plugin.MultiSelection',
        'Ext.grid.plugin.RowExpander',
        'Ext.grid.plugin.Exporter',
        
        'GridModern.view.main.BigDataRowModel',
        'GridModern.view.main.BigDataController',
        'GridModern.model.Employee'
    ],

    cls: 'demo-solid-background',

    shadow: true,

    controller: 'grid-bigdata',

    grouped: true,

    rowLines: true,
   

    store: {
        fields: [{
            name: 'employeeNo'
        }, {
            name: 'rating'
        }, {
            name: 'averageRating',
            calculate: function (data) {
                var average, i,
                    ratings = data.rating || [],
                    count = ratings.length;

                for (i = 0, average = 0; i < count; i++) {
                    average += data.rating[i];
                }
                return average / ratings.length;
            }
        }, {
            name: 'salary',
            type: 'number'
        }, {
            name: 'forename'
        }, {
            name: 'surname'
        }, {
            name: 'fullName',
            calculate: function (data) {
                return data.forename + ' ' + data.surname;
            }
        }, {
            name: 'email'
        }, {
            name: 'department'
        }, {
            name: 'dob',
            type: 'date',
            dateFormat: 'Ymd'
        }, {
            name: 'joinDate',
            type: 'date',
            dateFormat: 'Ymd'
        }, {
            name: 'noticePeriod'
        }, {
            name: 'sickDays',
            type: 'integer'
        }, {
            name: 'holidayDays',
            type: 'integer'
        }, {
            name: 'holidayAllowance',
            type: 'integer'
        }, {
            name: 'avatar'
        }, {
            name: 'ratingLastYear',
            type: 'integer'
        }, {
            name: 'ratingThisYear',
            type: 'integer'
        }],
        idField: 'employeeNo',
        autoLoad: true,
        groupField: 'department',
        pageSize: 0,
        data:{items: [{
            employeeNo: "455476",
            rating: [9,1,2,2,0,3,7,7,7,0],
            salary: 100,
            forename: "Abe",
            surname: "Maintz",
            email: "abe.maintz@sentcha.com",
            department: "Sales",
            dob: "19680309",
            joinDate: "20080612",
            sickDays: 4,
            holidayDays: 4,
            holidayAllowance: 33,
            noticePeriod: "2 weeks",
            avatar: "https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcSdj-gG2gXPkOUJGQ2r-3A5AnIgASv19axozeYMWssSVJyySvBIeQ"
        },
        {
            employeeNo: "140115",
            rating: [
                0,
                4,
                5,
                6,
                7,
                6,
                4,
                5,
                7,
                2
            ],
            salary: 400,
            forename: "David",
            surname: "Elias",
            email: "david.elias@sentcha.com",
            department: "Engineering",
            dob: "19840318",
            joinDate: "20071112",
            sickDays: 1,
            holidayDays: 4,
            holidayAllowance: 34,
            noticePeriod: "1 month",
            avatar: "https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcSdj-gG2gXPkOUJGQ2r-3A5AnIgASv19axozeYMWssSVJyySvBIeQ"
        },
    {
        employeeNo: "647265",
        rating: [
            6,
            10,
            1,
            8,
            8,
            2,
            10,
            7,
            7,
            2
        ],
        salary: 400,
        forename: "Tommy",
        surname: "Robinson",
        email: "tommy.robinson@sentcha.com",
        department: "Sales",
        dob: "19880806",
        joinDate: "20121108",
        sickDays: 4,
        holidayDays: 2,
        holidayAllowance: 40,
        noticePeriod: "2 weeks",
        avatar: "https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcSdj-gG2gXPkOUJGQ2r-3A5AnIgASv19axozeYMWssSVJyySvBIeQ"
    },
{
    employeeNo: "700103",
    rating: [
        8,
        8,
        5,
        8,
        10,
        4,
        2,
        6,
        10,
        10
    ],
    salary: 1000000,
    forename: "Tommy",
    surname: "Conran",
    email: "tommy.conran@sentcha.com",
    department: "Support",
    dob: "19890316",
    joinDate: "20080815",
    sickDays: 7,
    holidayDays: 9,
    holidayAllowance: 21,
    noticePeriod: "3 months",
    avatar: "https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcSdj-gG2gXPkOUJGQ2r-3A5AnIgASv19axozeYMWssSVJyySvBIeQ"
},
			{
			    employeeNo: "031710",
			    rating: [
					7,
					3,
					1,
					10,
					5,
					9,
					5,
					10,
					10,
					8
			    ],
			    salary: 1500,
			    forename: "Adam",
			    surname: "Mishcon",
			    email: "adam.mishcon@sentcha.com",
			    department: "Sales",
			    dob: "19700407",
			    joinDate: "20120626",
			    sickDays: 10,
			    holidayDays: 3,
			    holidayAllowance: 27,
			    noticePeriod: "3 months",
			    avatar: "https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcSdj-gG2gXPkOUJGQ2r-3A5AnIgASv19axozeYMWssSVJyySvBIeQ"
			},
			{
			    employeeNo: "201300",
			    rating: [
					0,
					8,
					0,
					4,
					4,
					1,
					3,
					3,
					5,
					4
			    ],
			    salary: 400,
			    forename: "Tommy",
			    surname: "Maintz",
			    email: "tommy.maintz@sentcha.com",
			    department: "Marketing",
			    dob: "19770115",
			    joinDate: "20071018",
			    sickDays: 9,
			    holidayDays: 0,
			    holidayAllowance: 25,
			    noticePeriod: "1 month",
			    avatar: "https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcSdj-gG2gXPkOUJGQ2r-3A5AnIgASv19axozeYMWssSVJyySvBIeQ"
			},
			{
			    employeeNo: "335141",
			    rating: [
					8,
					1,
					8,
					3,
					7,
					7,
					5,
					2,
					2,
					5
			    ],
			    salary: 100,
			    forename: "Nicolas",
			    surname: "Ferrero",
			    email: "nicolas.ferrero@sentcha.com",
			    department: "Administration",
			    dob: "19830228",
			    joinDate: "20120802",
			    sickDays: 8,
			    holidayDays: 10,
			    holidayAllowance: 32,
			    noticePeriod: "2 weeks",
			    avatar: "https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcSdj-gG2gXPkOUJGQ2r-3A5AnIgASv19axozeYMWssSVJyySvBIeQ"
			},
			{
			    employeeNo: "247614",
			    rating: [
					10,
					4,
					10,
					6,
					4,
					7,
					10,
					1,
					4,
					0
			    ],
			    salary: 1500,
			    forename: "Adam",
			    surname: "Robinson",
			    email: "adam.robinson@sentcha.com",
			    department: "Support",
			    dob: "19600425",
			    joinDate: "20110219",
			    sickDays: 9,
			    holidayDays: 3,
			    holidayAllowance: 40,
			    noticePeriod: "3 months",
			    avatar: "https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcSdj-gG2gXPkOUJGQ2r-3A5AnIgASv19axozeYMWssSVJyySvBIeQ"
			},
			{
			    employeeNo: "662167",
			    rating: [
					8,
					6,
					0,
					7,
					2,
					0,
					6,
					10,
					5,
					1
			    ],
			    salary: 1000000,
			    forename: "Nicolas",
			    surname: "Ferrero",
			    email: "nicolas.ferrero@sentcha.com",
			    department: "Marketing",
			    dob: "19650424",
			    joinDate: "20120910",
			    sickDays: 6,
			    holidayDays: 2,
			    holidayAllowance: 25,
			    noticePeriod: "2 weeks",
			    avatar: "https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcSdj-gG2gXPkOUJGQ2r-3A5AnIgASv19axozeYMWssSVJyySvBIeQ"
			},
			{
			    employeeNo: "721372",
			    rating: [
					9,
					6,
					10,
					2,
					8,
					3,
					0,
					10,
					7,
					9
			    ],
			    salary: 1500,
			    forename: "Abe",
			    surname: "Maintz",
			    email: "abe.maintz@sentcha.com",
			    department: "QA",
			    dob: "19800517",
			    joinDate: "20091028",
			    sickDays: 10,
			    holidayDays: 5,
			    holidayAllowance: 22,
			    noticePeriod: "3 months",
			    avatar: "https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcSdj-gG2gXPkOUJGQ2r-3A5AnIgASv19axozeYMWssSVJyySvBIeQ"
			},
			{
			    employeeNo: "052727",
			    rating: [
					9,
					7,
					3,
					4,
					0,
					0,
					1,
					9,
					6,
					6
			    ],
			    salary: 900,
			    forename: "Tommy",
			    surname: "Ferrero",
			    email: "tommy.ferrero@sentcha.com",
			    department: "Engineering",
			    dob: "19811112",
			    joinDate: "20100508",
			    sickDays: 10,
			    holidayDays: 0,
			    holidayAllowance: 39,
			    noticePeriod: "1 month",
			    avatar: "https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcSdj-gG2gXPkOUJGQ2r-3A5AnIgASv19axozeYMWssSVJyySvBIeQ"
			},
			{
			    employeeNo: "766305",
			    rating: [
					1,
					4,
					0,
					3,
					6,
					9,
					10,
					0,
					8,
					6
			    ],
			    salary: 900,
			    forename: "Abe",
			    surname: "Kaneda",
			    email: "abe.kaneda@sentcha.com",
			    department: "Managment",
			    dob: "19900325",
			    joinDate: "20090816",
			    sickDays: 8,
			    holidayDays: 10,
			    holidayAllowance: 27,
			    noticePeriod: "1 month",
			    avatar: "https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcSdj-gG2gXPkOUJGQ2r-3A5AnIgASv19axozeYMWssSVJyySvBIeQ"
			},
			{
			    employeeNo: "632255",
			    rating: [
					1,
					8,
					2,
					10,
					7,
					7,
					10,
					10,
					9,
					2
			    ],
			    salary: 1500,
			    forename: "Aaron",
			    surname: "Mishcon",
			    email: "aaron.mishcon@sentcha.com",
			    department: "Sales",
			    dob: "19880629",
			    joinDate: "20090927",
			    sickDays: 7,
			    holidayDays: 4,
			    holidayAllowance: 21,
			    noticePeriod: "2 weeks",
			    avatar: "https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcSdj-gG2gXPkOUJGQ2r-3A5AnIgASv19axozeYMWssSVJyySvBIeQ"
			},
			{
			    employeeNo: "466044",
			    rating: [
					9,
					6,
					4,
					7,
					10,
					10,
					0,
					2,
					3,
					7
			    ],
			    salary: 1000000,
			    forename: "Adam",
			    surname: "Robinson",
			    email: "adam.robinson@sentcha.com",
			    department: "Engineering",
			    dob: "19850203",
			    joinDate: "20090312",
			    sickDays: 7,
			    holidayDays: 6,
			    holidayAllowance: 37,
			    noticePeriod: "3 months",
			    avatar: "https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcSdj-gG2gXPkOUJGQ2r-3A5AnIgASv19axozeYMWssSVJyySvBIeQ"
			},
			{
			    employeeNo: "637555",
			    rating: [
					4,
					3,
					5,
					5,
					8,
					5,
					9,
					3,
					8,
					1
			    ],
			    salary: 100,
			    forename: "David",
			    surname: "White",
			    email: "david.white@sentcha.com",
			    department: "Support",
			    dob: "19670126",
			    joinDate: "20121021",
			    sickDays: 0,
			    holidayDays: 2,
			    holidayAllowance: 20,
			    noticePeriod: "1 month",
			    avatar: "https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcSdj-gG2gXPkOUJGQ2r-3A5AnIgASv19axozeYMWssSVJyySvBIeQ"
			},
			{
			    employeeNo: "220170",
			    rating: [
					4,
					3,
					9,
					10,
					3,
					5,
					5,
					9,
					7,
					3
			    ],
			    salary: 1000000,
			    forename: "Adam",
			    surname: "White",
			    email: "adam.white@sentcha.com",
			    department: "Engineering",
			    dob: "19630831",
			    joinDate: "20100424",
			    sickDays: 2,
			    holidayDays: 1,
			    holidayAllowance: 24,
			    noticePeriod: "2 weeks",
			    avatar: "https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcSdj-gG2gXPkOUJGQ2r-3A5AnIgASv19axozeYMWssSVJyySvBIeQ"
			},
			{
			    employeeNo: "032470",
			    rating: [
					8,
					6,
					3,
					10,
					10,
					10,
					3,
					0,
					2,
					9
			    ],
			    salary: 1000000,
			    forename: "Dave",
			    surname: "Robinson",
			    email: "dave.robinson@sentcha.com",
			    department: "Engineering",
			    dob: "19600420",
			    joinDate: "20100929",
			    sickDays: 4,
			    holidayDays: 9,
			    holidayAllowance: 39,
			    noticePeriod: "3 months",
			    avatar: "https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcSdj-gG2gXPkOUJGQ2r-3A5AnIgASv19axozeYMWssSVJyySvBIeQ"
			},
			{
			    employeeNo: "663655",
			    rating: [
					9,
					1,
					0,
					9,
					6,
					5,
					6,
					4,
					3,
					3
			    ],
			    salary: 900,
			    forename: "Jamie",
			    surname: "Spencer",
			    email: "jamie.spencer@sentcha.com",
			    department: "Marketing",
			    dob: "19750303",
			    joinDate: "20110724",
			    sickDays: 0,
			    holidayDays: 6,
			    holidayAllowance: 35,
			    noticePeriod: "3 months",
			    avatar: "https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcSdj-gG2gXPkOUJGQ2r-3A5AnIgASv19axozeYMWssSVJyySvBIeQ"
			},
			{
			    employeeNo: "327550",
			    rating: [
					7,
					4,
					3,
					7,
					7,
					2,
					7,
					5,
					8,
					1
			    ],
			    salary: 1000000,
			    forename: "Aaron",
			    surname: "Conran",
			    email: "aaron.conran@sentcha.com",
			    department: "Support",
			    dob: "19760820",
			    joinDate: "20121011",
			    sickDays: 8,
			    holidayDays: 1,
			    holidayAllowance: 29,
			    noticePeriod: "1 month",
			    avatar: "https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcSdj-gG2gXPkOUJGQ2r-3A5AnIgASv19axozeYMWssSVJyySvBIeQ"
			},
			{
			    employeeNo: "207676",
			    rating: [
					9,
					0,
					6,
					0,
					6,
					7,
					5,
					3,
					10,
					10
			    ],
			    salary: 1500,
			    forename: "Adam",
			    surname: "Kaneda",
			    email: "adam.kaneda@sentcha.com",
			    department: "Marketing",
			    dob: "19730625",
			    joinDate: "20080810",
			    sickDays: 10,
			    holidayDays: 8,
			    holidayAllowance: 25,
			    noticePeriod: "3 months",
			    avatar: "https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcSdj-gG2gXPkOUJGQ2r-3A5AnIgASv19axozeYMWssSVJyySvBIeQ"
			},
			{
			    employeeNo: "137555",
			    rating: [
					8,
					4,
					6,
					7,
					0,
					4,
					7,
					4,
					3,
					3
			    ],
			    salary: 900,
			    forename: "Nige",
			    surname: "Mishcon",
			    email: "nige.mishcon@sentcha.com",
			    department: "Accounting",
			    dob: "19680120",
			    joinDate: "20120421",
			    sickDays: 1,
			    holidayDays: 0,
			    holidayAllowance: 23,
			    noticePeriod: "1 month",
			    avatar: "https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcSdj-gG2gXPkOUJGQ2r-3A5AnIgASv19axozeYMWssSVJyySvBIeQ"
			}, {
			    employeeNo: "171633",
			    rating: [
					5,
					9,
					7,
					0,
					1,
					0,
					9,
					7,
					4,
					4
			    ],
			    salary: 400,
			    forename: "Aaron",
			    surname: "Elias",
			    email: "aaron.elias@sentcha.com",
			    department: "Administration",
			    dob: "19580721",
			    joinDate: "20120202",
			    sickDays: 4,
			    holidayDays: 8,
			    holidayAllowance: 37,
			    noticePeriod: "3 months",
			    avatar: "https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcSdj-gG2gXPkOUJGQ2r-3A5AnIgASv19axozeYMWssSVJyySvBIeQ"
			},
			{
			    employeeNo: "322626",
			    rating: [
					8,
					1,
					4,
					9,
					4,
					7,
					8,
					3,
					9,
					5
			    ],
			    salary: 1000000,
			    forename: "Tommy",
			    surname: "Conran",
			    email: "tommy.conran@sentcha.com",
			    department: "Engineering",
			    dob: "19861108",
			    joinDate: "20090320",
			    sickDays: 1,
			    holidayDays: 4,
			    holidayAllowance: 29,
			    noticePeriod: "2 weeks",
			    avatar: "https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcSdj-gG2gXPkOUJGQ2r-3A5AnIgASv19axozeYMWssSVJyySvBIeQ"
			},
			{
			    employeeNo: "770013",
			    rating: [
					7,
					2,
					2,
					8,
					9,
					10,
					1,
					4,
					6,
					8
			    ],
			    salary: 100,
			    forename: "Nicolas",
			    surname: "Avins",
			    email: "nicolas.avins@sentcha.com",
			    department: "Sales",
			    dob: "19880709",
			    joinDate: "20100806",
			    sickDays: 10,
			    holidayDays: 10,
			    holidayAllowance: 38,
			    noticePeriod: "1 month",
			    avatar: "https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcSdj-gG2gXPkOUJGQ2r-3A5AnIgASv19axozeYMWssSVJyySvBIeQ"
			},
			{
			    employeeNo: "343400",
			    rating: [
					1,
					1,
					3,
					4,
					0,
					8,
					3,
					2,
					5,
					10
			    ],
			    salary: 1500,
			    forename: "Jamie",
			    surname: "Elias",
			    email: "jamie.elias@sentcha.com",
			    department: "Administration",
			    dob: "19660131",
			    joinDate: "20080729",
			    sickDays: 5,
			    holidayDays: 5,
			    holidayAllowance: 26,
			    noticePeriod: "3 months",
			    avatar: "https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcSdj-gG2gXPkOUJGQ2r-3A5AnIgASv19axozeYMWssSVJyySvBIeQ"
			},
			{
			    employeeNo: "152604",
			    rating: [
					7,
					3,
					9,
					1,
					4,
					1,
					9,
					8,
					2,
					5
			    ],
			    salary: 900,
			    forename: "Nige",
			    surname: "Ferrero",
			    email: "nige.ferrero@sentcha.com",
			    department: "Sales",
			    dob: "19760816",
			    joinDate: "20110927",
			    sickDays: 9,
			    holidayDays: 2,
			    holidayAllowance: 27,
			    noticePeriod: "1 month",
			    avatar: "https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcSdj-gG2gXPkOUJGQ2r-3A5AnIgASv19axozeYMWssSVJyySvBIeQ"
			},
			{
			    employeeNo: "121274",
			    rating: [
					1,
					3,
					4,
					5,
					1,
					6,
					6,
					4,
					7,
					10
			    ],
			    salary: 400,
			    forename: "David",
			    surname: "Conran",
			    email: "david.conran@sentcha.com",
			    department: "Marketing",
			    dob: "19611123",
			    joinDate: "20100304",
			    sickDays: 1,
			    holidayDays: 8,
			    holidayAllowance: 26,
			    noticePeriod: "1 month",
			    avatar: "https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcSdj-gG2gXPkOUJGQ2r-3A5AnIgASv19axozeYMWssSVJyySvBIeQ"
			},
			{
			    employeeNo: "217706",
			    rating: [
					4,
					8,
					2,
					6,
					6,
					4,
					0,
					10,
					4,
					1
			    ],
			    salary: 1500,
			    forename: "David",
			    surname: "Robinson",
			    email: "david.robinson@sentcha.com",
			    department: "Engineering",
			    dob: "19770526",
			    joinDate: "20090509",
			    sickDays: 4,
			    holidayDays: 5,
			    holidayAllowance: 22,
			    noticePeriod: "2 weeks",
			    avatar: "https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcSdj-gG2gXPkOUJGQ2r-3A5AnIgASv19axozeYMWssSVJyySvBIeQ"
			},
			{
			    employeeNo: "476050",
			    rating: [
					1,
					4,
					6,
					10,
					5,
					10,
					0,
					3,
					8,
					0
			    ],
			    salary: 900,
			    forename: "Jay",
			    surname: "Conran",
			    email: "jay.conran@sentcha.com",
			    department: "Sales",
			    dob: "19720504",
			    joinDate: "20101005",
			    sickDays: 6,
			    holidayDays: 1,
			    holidayAllowance: 32,
			    noticePeriod: "1 month",
			    avatar: "https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcSdj-gG2gXPkOUJGQ2r-3A5AnIgASv19axozeYMWssSVJyySvBIeQ"
			},
			{
			    employeeNo: "707021",
			    rating: [
					5,
					0,
					1,
					2,
					5,
					0,
					8,
					0,
					3,
					6
			    ],
			    salary: 1500,
			    forename: "Aaron",
			    surname: "Mishcon",
			    email: "aaron.mishcon@sentcha.com",
			    department: "Marketing",
			    dob: "19820815",
			    joinDate: "20100430",
			    sickDays: 0,
			    holidayDays: 7,
			    holidayAllowance: 24,
			    noticePeriod: "1 month",
			    avatar: "https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcSdj-gG2gXPkOUJGQ2r-3A5AnIgASv19axozeYMWssSVJyySvBIeQ"
			},
			{
			    employeeNo: "775236",
			    rating: [
					8,
					8,
					3,
					9,
					0,
					9,
					7,
					4,
					1,
					2
			    ],
			    salary: 400,
			    forename: "Tommy",
			    surname: "Ferrero",
			    email: "tommy.ferrero@sentcha.com",
			    department: "QA",
			    dob: "19600824",
			    joinDate: "20080929",
			    sickDays: 7,
			    holidayDays: 0,
			    holidayAllowance: 33,
			    noticePeriod: "1 month",
			    avatar: "https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcSdj-gG2gXPkOUJGQ2r-3A5AnIgASv19axozeYMWssSVJyySvBIeQ"
			},
			{
			    employeeNo: "522322",
			    rating: [
					8,
					3,
					4,
					3,
					6,
					3,
					0,
					8,
					3,
					6
			    ],
			    salary: 1000000,
			    forename: "Aaron",
			    surname: "Spencer",
			    email: "aaron.spencer@sentcha.com",
			    department: "Sales",
			    dob: "19610122",
			    joinDate: "20120731",
			    sickDays: 9,
			    holidayDays: 7,
			    holidayAllowance: 22,
			    noticePeriod: "3 months",
			    avatar: "https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcSdj-gG2gXPkOUJGQ2r-3A5AnIgASv19axozeYMWssSVJyySvBIeQ"
			},
			{
			    employeeNo: "067376",
			    rating: [
					8,
					4,
					7,
					10,
					10,
					8,
					5,
					8,
					9,
					7
			    ],
			    salary: 900,
			    forename: "Jay",
			    surname: "Ferrero",
			    email: "jay.ferrero@sentcha.com",
			    department: "Engineering",
			    dob: "19801214",
			    joinDate: "20120215",
			    sickDays: 8,
			    holidayDays: 10,
			    holidayAllowance: 30,
			    noticePeriod: "3 months",
			    avatar: "https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcSdj-gG2gXPkOUJGQ2r-3A5AnIgASv19axozeYMWssSVJyySvBIeQ"
			},
			{
			    employeeNo: "572562",
			    rating: [
					8,
					6,
					0,
					1,
					4,
					8,
					9,
					10,
					1,
					2
			    ],
			    salary: 1000000,
			    forename: "Nicolas",
			    surname: "Spencer",
			    email: "nicolas.spencer@sentcha.com",
			    department: "Sales",
			    dob: "19780330",
			    joinDate: "20081118",
			    sickDays: 4,
			    holidayDays: 1,
			    holidayAllowance: 38,
			    noticePeriod: "1 month",
			    avatar: "https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcSdj-gG2gXPkOUJGQ2r-3A5AnIgASv19axozeYMWssSVJyySvBIeQ"
			},
			{
			    employeeNo: "773461",
			    rating: [
					2,
					1,
					2,
					3,
					1,
					1,
					2,
					1,
					0,
					10
			    ],
			    salary: 900,
			    forename: "Abe",
			    surname: "Robinson",
			    email: "abe.robinson@sentcha.com",
			    department: "Administration",
			    dob: "19800522",
			    joinDate: "20100801",
			    sickDays: 6,
			    holidayDays: 1,
			    holidayAllowance: 20,
			    noticePeriod: "1 month",
			    avatar: "https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcSdj-gG2gXPkOUJGQ2r-3A5AnIgASv19axozeYMWssSVJyySvBIeQ"
			},
			{
			    employeeNo: "442314",
			    rating: [
					9,
					9,
					4,
					10,
					8,
					1,
					8,
					0,
					7,
					7
			    ],
			    salary: 1000000,
			    forename: "Aaron",
			    surname: "Davis",
			    email: "aaron.davis@sentcha.com",
			    department: "QA",
			    dob: "19700501",
			    joinDate: "20120212",
			    sickDays: 1,
			    holidayDays: 2,
			    holidayAllowance: 36,
			    noticePeriod: "1 month",
			    avatar: "https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcSdj-gG2gXPkOUJGQ2r-3A5AnIgASv19axozeYMWssSVJyySvBIeQ"
			},
			{
			    employeeNo: "432773",
			    rating: [
					3,
					8,
					1,
					6,
					4,
					9,
					6,
					7,
					0,
					1
			    ],
			    salary: 1500,
			    forename: "Tommy",
			    surname: "Mishcon",
			    email: "tommy.mishcon@sentcha.com",
			    department: "Managment",
			    dob: "19820701",
			    joinDate: "20120915",
			    sickDays: 6,
			    holidayDays: 7,
			    holidayAllowance: 35,
			    noticePeriod: "2 weeks",
			    avatar: "https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcSdj-gG2gXPkOUJGQ2r-3A5AnIgASv19axozeYMWssSVJyySvBIeQ"
			},
			{
			    employeeNo: "201416",
			    rating: [
					3,
					10,
					8,
					5,
					6,
					8,
					7,
					7,
					7,
					7
			    ],
			    salary: 1500,
			    forename: "Nicolas",
			    surname: "Elias",
			    email: "nicolas.elias@sentcha.com",
			    department: "Administration",
			    dob: "19710917",
			    joinDate: "20100615",
			    sickDays: 9,
			    holidayDays: 5,
			    holidayAllowance: 30,
			    noticePeriod: "2 weeks",
			    avatar: "https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcSdj-gG2gXPkOUJGQ2r-3A5AnIgASv19axozeYMWssSVJyySvBIeQ"
			},
			{
			    employeeNo: "322300",
			    rating: [
					0,
					4,
					7,
					1,
					10,
					7,
					0,
					10,
					5,
					10
			    ],
			    salary: 400,
			    forename: "Abe",
			    surname: "Spencer",
			    email: "abe.spencer@sentcha.com",
			    department: "Sales",
			    dob: "19840122",
			    joinDate: "20090925",
			    sickDays: 4,
			    holidayDays: 5,
			    holidayAllowance: 33,
			    noticePeriod: "1 month",
			    avatar: "https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcSdj-gG2gXPkOUJGQ2r-3A5AnIgASv19axozeYMWssSVJyySvBIeQ"
			},
			{
			    employeeNo: "237144",
			    rating: [
					4,
					10,
					5,
					2,
					0,
					0,
					7,
					8,
					4,
					5
			    ],
			    salary: 900,
			    forename: "Dave",
			    surname: "White",
			    email: "dave.white@sentcha.com",
			    department: "Support",
			    dob: "19820814",
			    joinDate: "20100423",
			    sickDays: 0,
			    holidayDays: 4,
			    holidayAllowance: 34,
			    noticePeriod: "3 months",
			    avatar: "https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcSdj-gG2gXPkOUJGQ2r-3A5AnIgASv19axozeYMWssSVJyySvBIeQ"
			},
			{
			    employeeNo: "576347",
			    rating: [
					4,
					9,
					8,
					0,
					5,
					9,
					5,
					7,
					10,
					5
			    ],
			    salary: 100,
			    forename: "David",
			    surname: "Ferrero",
			    email: "david.ferrero@sentcha.com",
			    department: "QA",
			    dob: "19810117",
			    joinDate: "20080104",
			    sickDays: 6,
			    holidayDays: 0,
			    holidayAllowance: 21,
			    noticePeriod: "1 month",
			    avatar: "https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcSdj-gG2gXPkOUJGQ2r-3A5AnIgASv19axozeYMWssSVJyySvBIeQ"
			},
			{
			    employeeNo: "014607",
			    rating: [
					10,
					5,
					0,
					4,
					8,
					0,
					3,
					5,
					4,
					0
			    ],
			    salary: 1000000,
			    forename: "Nige",
			    surname: "White",
			    email: "nige.white@sentcha.com",
			    department: "Accounting",
			    dob: "19580226",
			    joinDate: "20080828",
			    sickDays: 3,
			    holidayDays: 6,
			    holidayAllowance: 20,
			    noticePeriod: "1 month",
			    avatar: "https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcSdj-gG2gXPkOUJGQ2r-3A5AnIgASv19axozeYMWssSVJyySvBIeQ"
			},
			{
			    employeeNo: "361321",
			    rating: [
					2,
					3,
					9,
					0,
					4,
					4,
					8,
					2,
					0,
					9
			    ],
			    salary: 1000000,
			    forename: "Jamie",
			    surname: "Davis",
			    email: "jamie.davis@sentcha.com",
			    department: "Accounting",
			    dob: "19620104",
			    joinDate: "20080706",
			    sickDays: 8,
			    holidayDays: 3,
			    holidayAllowance: 38,
			    noticePeriod: "3 months",
			    avatar: "https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcSdj-gG2gXPkOUJGQ2r-3A5AnIgASv19axozeYMWssSVJyySvBIeQ"
			},
			{
			    employeeNo: "412312",
			    rating: [
					1,
					9,
					2,
					6,
					10,
					8,
					10,
					6,
					5,
					7
			    ],
			    salary: 100,
			    forename: "Nige",
			    surname: "Ferrero",
			    email: "nige.ferrero@sentcha.com",
			    department: "QA",
			    dob: "19661016",
			    joinDate: "20100912",
			    sickDays: 4,
			    holidayDays: 3,
			    holidayAllowance: 39,
			    noticePeriod: "2 weeks",
			    avatar: "https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcSdj-gG2gXPkOUJGQ2r-3A5AnIgASv19axozeYMWssSVJyySvBIeQ"
			},
			{
			    employeeNo: "650414",
			    rating: [
					4,
					9,
					7,
					0,
					9,
					0,
					2,
					1,
					2,
					7
			    ],
			    salary: 100,
			    forename: "Nige",
			    surname: "Spencer",
			    email: "nige.spencer@sentcha.com",
			    department: "Sales",
			    dob: "19790520",
			    joinDate: "20090419",
			    sickDays: 0,
			    holidayDays: 3,
			    holidayAllowance: 20,
			    noticePeriod: "1 month",
			    avatar: "https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcSdj-gG2gXPkOUJGQ2r-3A5AnIgASv19axozeYMWssSVJyySvBIeQ"
			},
			{
			    employeeNo: "443136",
			    rating: [
					1,
					6,
					6,
					7,
					10,
					7,
					6,
					0,
					9,
					5
			    ],
			    salary: 100,
			    forename: "David",
			    surname: "Mishcon",
			    email: "david.mishcon@sentcha.com",
			    department: "QA",
			    dob: "19880426",
			    joinDate: "20080617",
			    sickDays: 9,
			    holidayDays: 4,
			    holidayAllowance: 36,
			    noticePeriod: "3 months",
			    avatar: "https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcSdj-gG2gXPkOUJGQ2r-3A5AnIgASv19axozeYMWssSVJyySvBIeQ"
			},
			{
			    employeeNo: "564276",
			    rating: [
					0,
					5,
					0,
					9,
					1,
					7,
					2,
					3,
					6,
					6
			    ],
			    salary: 1000000,
			    forename: "Aaron",
			    surname: "Robinson",
			    email: "aaron.robinson@sentcha.com",
			    department: "Sales",
			    dob: "19651228",
			    joinDate: "20110901",
			    sickDays: 3,
			    holidayDays: 6,
			    holidayAllowance: 36,
			    noticePeriod: "2 weeks",
			    avatar: "https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcSdj-gG2gXPkOUJGQ2r-3A5AnIgASv19axozeYMWssSVJyySvBIeQ"
			},
			{
			    employeeNo: "670147",
			    rating: [
					7,
					0,
					3,
					7,
					7,
					5,
					9,
					4,
					6,
					6
			    ],
			    salary: 1000000,
			    forename: "Adam",
			    surname: "Conran",
			    email: "adam.conran@sentcha.com",
			    department: "Marketing",
			    dob: "19620606",
			    joinDate: "20090527",
			    sickDays: 8,
			    holidayDays: 10,
			    holidayAllowance: 22,
			    noticePeriod: "2 weeks",
			    avatar: "https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcSdj-gG2gXPkOUJGQ2r-3A5AnIgASv19axozeYMWssSVJyySvBIeQ"
			},
			{
			    employeeNo: "424527",
			    rating: [
					10,
					10,
					6,
					8,
					2,
					7,
					3,
					9,
					8,
					2
			    ],
			    salary: 1500,
			    forename: "Abe",
			    surname: "Conran",
			    email: "abe.conran@sentcha.com",
			    department: "QA",
			    dob: "19821203",
			    joinDate: "20120708",
			    sickDays: 7,
			    holidayDays: 5,
			    holidayAllowance: 22,
			    noticePeriod: "3 months",
			    avatar: "https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcSdj-gG2gXPkOUJGQ2r-3A5AnIgASv19axozeYMWssSVJyySvBIeQ"
			},
			{
			    employeeNo: "525730",
			    rating: [
					3,
					4,
					4,
					5,
					5,
					1,
					0,
					4,
					2,
					4
			    ],
			    salary: 900,
			    forename: "Aaron",
			    surname: "White",
			    email: "aaron.white@sentcha.com",
			    department: "Administration",
			    dob: "19730303",
			    joinDate: "20110714",
			    sickDays: 10,
			    holidayDays: 0,
			    holidayAllowance: 20,
			    noticePeriod: "2 weeks",
			    avatar: "https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcSdj-gG2gXPkOUJGQ2r-3A5AnIgASv19axozeYMWssSVJyySvBIeQ"
			},
			{
			    employeeNo: "432467",
			    rating: [
					10,
					9,
					8,
					10,
					0,
					7,
					6,
					4,
					8,
					0
			    ],
			    salary: 1500,
			    forename: "Jay",
			    surname: "Kaneda",
			    email: "jay.kaneda@sentcha.com",
			    department: "Accounting",
			    dob: "19751016",
			    joinDate: "20110822",
			    sickDays: 9,
			    holidayDays: 2,
			    holidayAllowance: 27,
			    noticePeriod: "3 months",
			    avatar: "https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcSdj-gG2gXPkOUJGQ2r-3A5AnIgASv19axozeYMWssSVJyySvBIeQ"
			}, {
			    employeeNo: "656526",
			    rating: [
					0,
					0,
					1,
					9,
					8,
					7,
					9,
					7,
					10,
					8
			    ],
			    salary: 900,
			    forename: "Dave",
			    surname: "Mishcon",
			    email: "dave.mishcon@sentcha.com",
			    department: "Administration",
			    dob: "19870827",
			    joinDate: "20100709",
			    sickDays: 4,
			    holidayDays: 5,
			    holidayAllowance: 30,
			    noticePeriod: "2 weeks",
			    avatar: "https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcSdj-gG2gXPkOUJGQ2r-3A5AnIgASv19axozeYMWssSVJyySvBIeQ"
			},
			{
			    employeeNo: "460001",
			    rating: [
					7,
					9,
					10,
					1,
					1,
					4,
					10,
					5,
					4,
					7
			    ],
			    salary: 1000000,
			    forename: "Abe",
			    surname: "White",
			    email: "abe.white@sentcha.com",
			    department: "Managment",
			    dob: "19900417",
			    joinDate: "20120328",
			    sickDays: 9,
			    holidayDays: 5,
			    holidayAllowance: 33,
			    noticePeriod: "3 months",
			    avatar: "https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcSdj-gG2gXPkOUJGQ2r-3A5AnIgASv19axozeYMWssSVJyySvBIeQ"
			},
			{
			    employeeNo: "503226",
			    rating: [
					4,
					9,
					0,
					1,
					9,
					5,
					7,
					6,
					1,
					9
			    ],
			    salary: 1500,
			    forename: "Tommy",
			    surname: "Spencer",
			    email: "tommy.spencer@sentcha.com",
			    department: "Engineering",
			    dob: "19650529",
			    joinDate: "20080601",
			    sickDays: 2,
			    holidayDays: 9,
			    holidayAllowance: 31,
			    noticePeriod: "2 weeks",
			    avatar: "https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcSdj-gG2gXPkOUJGQ2r-3A5AnIgASv19axozeYMWssSVJyySvBIeQ"
			},
			{
			    employeeNo: "144031",
			    rating: [
					2,
					3,
					0,
					3,
					2,
					5,
					6,
					10,
					5,
					2
			    ],
			    salary: 400,
			    forename: "Nicolas",
			    surname: "Davis",
			    email: "nicolas.davis@sentcha.com",
			    department: "Accounting",
			    dob: "19860821",
			    joinDate: "20091212",
			    sickDays: 8,
			    holidayDays: 7,
			    holidayAllowance: 35,
			    noticePeriod: "3 months",
			    avatar: "https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcSdj-gG2gXPkOUJGQ2r-3A5AnIgASv19axozeYMWssSVJyySvBIeQ"
			},
			{
			    employeeNo: "767525",
			    rating: [
					7,
					2,
					8,
					3,
					10,
					5,
					6,
					1,
					0,
					2
			    ],
			    salary: 400,
			    forename: "Jay",
			    surname: "Kaneda",
			    email: "jay.kaneda@sentcha.com",
			    department: "Engineering",
			    dob: "19761026",
			    joinDate: "20080217",
			    sickDays: 8,
			    holidayDays: 7,
			    holidayAllowance: 25,
			    noticePeriod: "3 months",
			    avatar: "https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcSdj-gG2gXPkOUJGQ2r-3A5AnIgASv19axozeYMWssSVJyySvBIeQ"
			},
			{
			    employeeNo: "473006",
			    rating: [
					8,
					8,
					7,
					3,
					10,
					10,
					4,
					10,
					6,
					5
			    ],
			    salary: 400,
			    forename: "Aaron",
			    surname: "Conran",
			    email: "aaron.conran@sentcha.com",
			    department: "Support",
			    dob: "19840413",
			    joinDate: "20121215",
			    sickDays: 4,
			    holidayDays: 9,
			    holidayAllowance: 23,
			    noticePeriod: "2 weeks",
			    avatar: "https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcSdj-gG2gXPkOUJGQ2r-3A5AnIgASv19axozeYMWssSVJyySvBIeQ"
			},
			{
			    employeeNo: "641444",
			    rating: [
					6,
					5,
					9,
					2,
					3,
					0,
					5,
					9,
					2,
					6
			    ],
			    salary: 1500,
			    forename: "Ed",
			    surname: "Robinson",
			    email: "ed.robinson@sentcha.com",
			    department: "Managment",
			    dob: "19630625",
			    joinDate: "20071203",
			    sickDays: 7,
			    holidayDays: 5,
			    holidayAllowance: 36,
			    noticePeriod: "1 month",
			    avatar: "https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcSdj-gG2gXPkOUJGQ2r-3A5AnIgASv19axozeYMWssSVJyySvBIeQ"
			},
			{
			    employeeNo: "054441",
			    rating: [
					1,
					10,
					9,
					0,
					8,
					6,
					3,
					3,
					10,
					3
			    ],
			    salary: 400,
			    forename: "Jamie",
			    surname: "Conran",
			    email: "jamie.conran@sentcha.com",
			    department: "Administration",
			    dob: "19760608",
			    joinDate: "20121112",
			    sickDays: 8,
			    holidayDays: 0,
			    holidayAllowance: 24,
			    noticePeriod: "1 month",
			    avatar: "https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcSdj-gG2gXPkOUJGQ2r-3A5AnIgASv19axozeYMWssSVJyySvBIeQ"
			},
			{
			    employeeNo: "076103",
			    rating: [
					1,
					5,
					9,
					5,
					5,
					3,
					10,
					8,
					10,
					0
			    ],
			    salary: 100,
			    forename: "Aaron",
			    surname: "Davis",
			    email: "aaron.davis@sentcha.com",
			    department: "QA",
			    dob: "19600810",
			    joinDate: "20111105",
			    sickDays: 8,
			    holidayDays: 0,
			    holidayAllowance: 31,
			    noticePeriod: "3 months",
			    avatar: "https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcSdj-gG2gXPkOUJGQ2r-3A5AnIgASv19axozeYMWssSVJyySvBIeQ"
			},
			{
			    employeeNo: "731316",
			    rating: [
					1,
					4,
					10,
					9,
					8,
					5,
					0,
					7,
					1,
					9
			    ],
			    salary: 1000000,
			    forename: "Nige",
			    surname: "White",
			    email: "nige.white@sentcha.com",
			    department: "QA",
			    dob: "19660731",
			    joinDate: "20111022",
			    sickDays: 4,
			    holidayDays: 7,
			    holidayAllowance: 37,
			    noticePeriod: "2 weeks",
			    avatar: "https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcSdj-gG2gXPkOUJGQ2r-3A5AnIgASv19axozeYMWssSVJyySvBIeQ"
			},
			{
			    employeeNo: "171415",
			    rating: [
					5,
					8,
					1,
					6,
					4,
					0,
					3,
					8,
					7,
					10
			    ],
			    salary: 1500,
			    forename: "Nige",
			    surname: "Spencer",
			    email: "nige.spencer@sentcha.com",
			    department: "Accounting",
			    dob: "19700512",
			    joinDate: "20091201",
			    sickDays: 10,
			    holidayDays: 4,
			    holidayAllowance: 32,
			    noticePeriod: "3 months",
			    avatar: "https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcSdj-gG2gXPkOUJGQ2r-3A5AnIgASv19axozeYMWssSVJyySvBIeQ"
			},
			{
			    employeeNo: "774543",
			    rating: [
					7,
					2,
					10,
					4,
					4,
					9,
					1,
					8,
					7,
					7
			    ],
			    salary: 1000000,
			    forename: "Abe",
			    surname: "Davis",
			    email: "abe.davis@sentcha.com",
			    department: "Engineering",
			    dob: "19590608",
			    joinDate: "20090325",
			    sickDays: 7,
			    holidayDays: 5,
			    holidayAllowance: 26,
			    noticePeriod: "3 months",
			    avatar: "https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcSdj-gG2gXPkOUJGQ2r-3A5AnIgASv19axozeYMWssSVJyySvBIeQ"
			},
			{
			    employeeNo: "522571",
			    rating: [
					7,
					2,
					5,
					10,
					10,
					7,
					0,
					6,
					2,
					10
			    ],
			    salary: 1000000,
			    forename: "Aaron",
			    surname: "Kaneda",
			    email: "aaron.kaneda@sentcha.com",
			    department: "Managment",
			    dob: "19770309",
			    joinDate: "20091113",
			    sickDays: 4,
			    holidayDays: 3,
			    holidayAllowance: 25,
			    noticePeriod: "1 month",
			    avatar: "https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcSdj-gG2gXPkOUJGQ2r-3A5AnIgASv19axozeYMWssSVJyySvBIeQ"
			},
			{
			    employeeNo: "437323",
			    rating: [
					10,
					8,
					0,
					8,
					6,
					7,
					7,
					7,
					2,
					5
			    ],
			    salary: 900,
			    forename: "Nicolas",
			    surname: "Kaneda",
			    email: "nicolas.kaneda@sentcha.com",
			    department: "Accounting",
			    dob: "19680807",
			    joinDate: "20090402",
			    sickDays: 3,
			    holidayDays: 10,
			    holidayAllowance: 25,
			    noticePeriod: "2 weeks",
			    avatar: "https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcSdj-gG2gXPkOUJGQ2r-3A5AnIgASv19axozeYMWssSVJyySvBIeQ"
			},
			{
			    employeeNo: "446021",
			    rating: [
					4,
					0,
					7,
					5,
					4,
					6,
					10,
					4,
					2,
					1
			    ],
			    salary: 400,
			    forename: "Jay",
			    surname: "Avins",
			    email: "jay.avins@sentcha.com",
			    department: "Engineering",
			    dob: "19720406",
			    joinDate: "20120630",
			    sickDays: 5,
			    holidayDays: 6,
			    holidayAllowance: 28,
			    noticePeriod: "3 months",
			    avatar: "https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcSdj-gG2gXPkOUJGQ2r-3A5AnIgASv19axozeYMWssSVJyySvBIeQ"
			},
			{
			    employeeNo: "331770",
			    rating: [
					8,
					2,
					6,
					2,
					6,
					9,
					2,
					10,
					10,
					6
			    ],
			    salary: 900,
			    forename: "Dave",
			    surname: "Spencer",
			    email: "dave.spencer@sentcha.com",
			    department: "Administration",
			    dob: "19710510",
			    joinDate: "20080301",
			    sickDays: 10,
			    holidayDays: 8,
			    holidayAllowance: 33,
			    noticePeriod: "3 months",
			    avatar: "https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcSdj-gG2gXPkOUJGQ2r-3A5AnIgASv19axozeYMWssSVJyySvBIeQ"
			},
			{
			    employeeNo: "731265",
			    rating: [
					2,
					2,
					1,
					10,
					1,
					8,
					6,
					10,
					3,
					5
			    ],
			    salary: 1000000,
			    forename: "Abe",
			    surname: "Davis",
			    email: "abe.davis@sentcha.com",
			    department: "Engineering",
			    dob: "19641102",
			    joinDate: "20110617",
			    sickDays: 10,
			    holidayDays: 8,
			    holidayAllowance: 28,
			    noticePeriod: "2 weeks",
			    avatar: "https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcSdj-gG2gXPkOUJGQ2r-3A5AnIgASv19axozeYMWssSVJyySvBIeQ"
			},
			{
			    employeeNo: "222335",
			    rating: [
					9,
					5,
					5,
					6,
					0,
					3,
					4,
					1,
					5,
					0
			    ],
			    salary: 1500,
			    forename: "Abe",
			    surname: "Davis",
			    email: "abe.davis@sentcha.com",
			    department: "Sales",
			    dob: "19861126",
			    joinDate: "20120118",
			    sickDays: 2,
			    holidayDays: 5,
			    holidayAllowance: 26,
			    noticePeriod: "1 month",
			    avatar: "https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcSdj-gG2gXPkOUJGQ2r-3A5AnIgASv19axozeYMWssSVJyySvBIeQ"
			},
			{
			    employeeNo: "257410",
			    rating: [
					5,
					8,
					10,
					2,
					0,
					7,
					3,
					7,
					8,
					0
			    ],
			    salary: 100,
			    forename: "David",
			    surname: "Avins",
			    email: "david.avins@sentcha.com",
			    department: "Engineering",
			    dob: "19700127",
			    joinDate: "20100222",
			    sickDays: 7,
			    holidayDays: 4,
			    holidayAllowance: 30,
			    noticePeriod: "2 weeks",
			    avatar: "https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcSdj-gG2gXPkOUJGQ2r-3A5AnIgASv19axozeYMWssSVJyySvBIeQ"
			},
			{
			    employeeNo: "324315",
			    rating: [
					3,
					6,
					4,
					4,
					6,
					5,
					4,
					10,
					0,
					9
			    ],
			    salary: 1000000,
			    forename: "Jay",
			    surname: "Conran",
			    email: "jay.conran@sentcha.com",
			    department: "Administration",
			    dob: "19580603",
			    joinDate: "20130115",
			    sickDays: 2,
			    holidayDays: 0,
			    holidayAllowance: 34,
			    noticePeriod: "1 month",
			    avatar: "https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcSdj-gG2gXPkOUJGQ2r-3A5AnIgASv19axozeYMWssSVJyySvBIeQ"
			},
			{
			    employeeNo: "157675",
			    rating: [
					10,
					9,
					7,
					6,
					4,
					7,
					7,
					1,
					6,
					7
			    ],
			    salary: 100,
			    forename: "Tommy",
			    surname: "Mishcon",
			    email: "tommy.mishcon@sentcha.com",
			    department: "Accounting",
			    dob: "19720608",
			    joinDate: "20120425",
			    sickDays: 3,
			    holidayDays: 8,
			    holidayAllowance: 39,
			    noticePeriod: "3 months",
			    avatar: "https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcSdj-gG2gXPkOUJGQ2r-3A5AnIgASv19axozeYMWssSVJyySvBIeQ"
			},
			{
			    employeeNo: "446403",
			    rating: [
					3,
					5,
					5,
					3,
					5,
					7,
					4,
					9,
					0,
					0
			    ],
			    salary: 1500,
			    forename: "Aaron",
			    surname: "Elias",
			    email: "aaron.elias@sentcha.com",
			    department: "QA",
			    dob: "19580205",
			    joinDate: "20110426",
			    sickDays: 10,
			    holidayDays: 6,
			    holidayAllowance: 32,
			    noticePeriod: "2 weeks",
			    avatar: "https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcSdj-gG2gXPkOUJGQ2r-3A5AnIgASv19axozeYMWssSVJyySvBIeQ"
			},
			{
			    employeeNo: "261547",
			    rating: [
					10,
					9,
					0,
					8,
					5,
					2,
					6,
					10,
					7,
					1
			    ],
			    salary: 1500,
			    forename: "Jamie",
			    surname: "Ferrero",
			    email: "jamie.ferrero@sentcha.com",
			    department: "Administration",
			    dob: "19770223",
			    joinDate: "20101119",
			    sickDays: 9,
			    holidayDays: 7,
			    holidayAllowance: 39,
			    noticePeriod: "3 months",
			    avatar: "https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcSdj-gG2gXPkOUJGQ2r-3A5AnIgASv19axozeYMWssSVJyySvBIeQ"
			},
			{
			    employeeNo: "253551",
			    rating: [
					8,
					9,
					1,
					3,
					6,
					1,
					4,
					0,
					8,
					8
			    ],
			    salary: 1000000,
			    forename: "Jay",
			    surname: "Maintz",
			    email: "jay.maintz@sentcha.com",
			    department: "Sales",
			    dob: "19890514",
			    joinDate: "20110117",
			    sickDays: 10,
			    holidayDays: 8,
			    holidayAllowance: 35,
			    noticePeriod: "2 weeks",
			    avatar: "https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcSdj-gG2gXPkOUJGQ2r-3A5AnIgASv19axozeYMWssSVJyySvBIeQ"
			},
			{
			    employeeNo: "736453",
			    rating: [
					8,
					5,
					3,
					1,
					0,
					7,
					4,
					2,
					1,
					6
			    ],
			    salary: 1000000,
			    forename: "David",
			    surname: "Kaneda",
			    email: "david.kaneda@sentcha.com",
			    department: "Administration",
			    dob: "19710507",
			    joinDate: "20080401",
			    sickDays: 6,
			    holidayDays: 5,
			    holidayAllowance: 25,
			    noticePeriod: "1 month",
			    avatar: "https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcSdj-gG2gXPkOUJGQ2r-3A5AnIgASv19axozeYMWssSVJyySvBIeQ"
			},
			{
			    employeeNo: "232770",
			    rating: [
					5,
					10,
					9,
					9,
					1,
					2,
					3,
					1,
					4,
					2
			    ],
			    salary: 1000000,
			    forename: "Jamie",
			    surname: "Avins",
			    email: "jamie.avins@sentcha.com",
			    department: "Administration",
			    dob: "19731024",
			    joinDate: "20100715",
			    sickDays: 1,
			    holidayDays: 7,
			    holidayAllowance: 39,
			    noticePeriod: "1 month",
			    avatar: "https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcSdj-gG2gXPkOUJGQ2r-3A5AnIgASv19axozeYMWssSVJyySvBIeQ"
			},
			{
			    employeeNo: "414402",
			    rating: [
					1,
					1,
					3,
					6,
					3,
					0,
					2,
					2,
					4,
					4
			    ],
			    salary: 100,
			    forename: "Nige",
			    surname: "Mishcon",
			    email: "nige.mishcon@sentcha.com",
			    department: "Administration",
			    dob: "19640808",
			    joinDate: "20081004",
			    sickDays: 4,
			    holidayDays: 6,
			    holidayAllowance: 38,
			    noticePeriod: "3 months",
			    avatar: "https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcSdj-gG2gXPkOUJGQ2r-3A5AnIgASv19axozeYMWssSVJyySvBIeQ"
			},
			{
			    employeeNo: "663270",
			    rating: [
					0,
					2,
					4,
					9,
					8,
					0,
					1,
					5,
					0,
					1
			    ],
			    salary: 1000000,
			    forename: "Adam",
			    surname: "Ferrero",
			    email: "adam.ferrero@sentcha.com",
			    department: "Marketing",
			    dob: "19621024",
			    joinDate: "20101215",
			    sickDays: 3,
			    holidayDays: 6,
			    holidayAllowance: 26,
			    noticePeriod: "1 month",
			    avatar: "https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcSdj-gG2gXPkOUJGQ2r-3A5AnIgASv19axozeYMWssSVJyySvBIeQ"
			},
			{
			    employeeNo: "643211",
			    rating: [
					7,
					2,
					10,
					2,
					4,
					6,
					1,
					3,
					5,
					6
			    ],
			    salary: 1000000,
			    forename: "Dave",
			    surname: "Elias",
			    email: "dave.elias@sentcha.com",
			    department: "Support",
			    dob: "19810715",
			    joinDate: "20080905",
			    sickDays: 1,
			    holidayDays: 8,
			    holidayAllowance: 35,
			    noticePeriod: "3 months",
			    avatar: "https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcSdj-gG2gXPkOUJGQ2r-3A5AnIgASv19axozeYMWssSVJyySvBIeQ"
			},
			{
			    employeeNo: "356411",
			    rating: [
					9,
					7,
					1,
					7,
					6,
					0,
					3,
					1,
					3,
					8
			    ],
			    salary: 1000000,
			    forename: "Jamie",
			    surname: "Conran",
			    email: "jamie.conran@sentcha.com",
			    department: "QA",
			    dob: "19820401",
			    joinDate: "20100325",
			    sickDays: 4,
			    holidayDays: 7,
			    holidayAllowance: 31,
			    noticePeriod: "2 weeks",
			    avatar: "https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcSdj-gG2gXPkOUJGQ2r-3A5AnIgASv19axozeYMWssSVJyySvBIeQ"
			},
			{
			    employeeNo: "520444",
			    rating: [
					2,
					6,
					5,
					5,
					8,
					0,
					7,
					10,
					3,
					1
			    ],
			    salary: 1000000,
			    forename: "Jamie",
			    surname: "Avins",
			    email: "jamie.avins@sentcha.com",
			    department: "Accounting",
			    dob: "19700607",
			    joinDate: "20130122",
			    sickDays: 0,
			    holidayDays: 7,
			    holidayAllowance: 26,
			    noticePeriod: "3 months",
			    avatar: "https://encrypted-tbn2.gstatic.com/images?q=tbn:ANd9GcSdj-gG2gXPkOUJGQ2r-3A5AnIgASv19axozeYMWssSVJyySvBIeQ"
			}]
        },
        proxy: {
            type: 'memory',
            reader: {
                type: 'json',
                rootProperty: 'items'
            }

        }
    },

    plugins: [{
        type: 'grideditable'
    }, {
        type: 'gridviewoptions'
    }, {
        type: 'pagingtoolbar'
    }, {
        type: 'summaryrow'
    }, {
        type: 'columnresizing'
    }, {
        type: 'rowexpander'
    }, {
        type: 'gridexporter'
    }],

    listeners: {
        documentsave: 'onDocumentSave',
        beforedocumentsave: 'onBeforeDocumentSave'
    },

    items: [{
        docked: 'top',
        xtype: 'toolbar',
        shadow: false,
        items: [{
            xtype: 'button',
            text: 'Export to ...',
            handler: 'exportTo'
        }]
    }],
    viewConfig: {
        stripeRows: false,
        getRowClass: function (record, index) {
            console.log('selected');
            if (parseInt(index) % 2 == 0) {
                return "child-row";
            } else {
                return 'adult-row';
            }
        }
    },



    
    // Instruct rows to create view models so we can use data binding
    itemConfig: {
        viewModel: {
            type: 'grid-bigdata-row'
        },
        body: {
            tpl: '<img src="{avatar}" height="100px" style="float:left;margin:0 10px 5px 0"><b>{name}<br></b>{dob:date}'
        }
    },

    columns: [
        {
            xtype: 'rownumberer'
        },
        {
            text: 'Id',
            dataIndex: 'employeeNo',
            flex: 1,
            minWidth: 100,
            exportStyle: {
                format: 'General Number',
                alignment: {
                    horizontal: 'Right'
                }
            }
        },
        {
            text: 'Name',
            dataIndex: 'fullName',
           
            minWidth: 150
        },
        {
            xtype: 'checkcolumn',
            headerCheckbox: true,
            dataIndex: 'verified',
            text: 'Verified'
        },
        {
            xtype: 'gridheadergroup',
            text: 'Ratings',
            columns: [{
                text: 'Avg',
                xtype: 'numbercolumn',
                dataIndex: 'averageRating',
                width: 75,
                summaryType: 'sum',
                cell: {
                    cls: 'big-data-ratings-cell',
                    bind: {
                        innerCls: '{ratingGroup:pick("under4","under5","under6","over6")}'
                    }
                }
            }, {
                text: 'All',
                dataIndex: 'rating',
                ignoreExport: true,
                cell: {
                    xtype: 'widgetcell',
                    forceWidth: true,
                    widget: {
                        xtype: 'sparklineline'
                    }
                }
            }]
        },
        {
            text: 'Date of Birth',
            dataIndex: 'dob',
            editable: true,
            xtype: 'datecolumn',
            format: 'd-m-Y',
            // you can define an export style for a column
            // you can set alignment, format etc
            exportStyle: [{
                // no type key is defined here which means that this is the default style
                // that will be used by all exporters
                format: 'Medium Date',
                alignment: {
                    horizontal: 'Right'
                }
            }, {
                // the type key means that this style will only be used by the csv exporter
                // and for all others the default one, defined above, will be used
                type: 'csv',
                format: 'Short Date'
            }]
        },
        {
            text: '',
            width: 100,
            ignoreExport: true,
            cell: {
                xtype: 'widgetcell',
                widget: {
                    xtype: 'button',
                    ui: 'action',
                    bind: 'Verify {record.firstName}',
                    handler: 'onVerifyTap'
                }
            }
        },
        {
            text: 'Join Date',
            dataIndex: 'joinDate',
            editable: true,
            xtype: 'datecolumn',
            format: 'd-m-Y',
            exportStyle: {
                format: 'Medium Date',
                alignment: {
                    horizontal: 'Right'
                }
            }
        },
        {
            text: 'Notice Period',
            dataIndex: 'noticePeriod',
            editable: true
        },
        {
            text: 'Email',
            dataIndex: 'email',
            editable: true,
            editor: {
                xtype: 'emailfield'
            },
            width: 250
        },
        {
            text: 'Absences',
            xtype: 'headergroup',
            columns: [{
                text: 'Illness',
                dataIndex: 'sickDays',
                align: 'center',
                summaryType: 'sum'
            }, {
                text: 'Holidays',
                dataIndex: 'holidayDays',
                align: 'center',
                summaryType: 'sum'
            }, {
                text: 'Holiday Allowance',
                dataIndex: 'holidayAllowance',
                align: 'center',
                summaryType: 'sum',
                summaryFormatter: 'number("0.00")',
                formatter: 'number("0.00")'
            }]
        },
        {
            text: 'Salary',
            dataIndex: 'salary',
            renderer: Ext.util.Format.usMoney,
            editable: true,
            width: 150,
            summaryType: 'sum',
            summaryRenderer: 'salarySummaryRenderer',
            exportStyle: {
                format: 'Currency',
                alignment: {
                    horizontal: 'Right'
                }
            }
        }
    ]
});