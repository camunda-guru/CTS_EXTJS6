﻿Ext.define('Product', {
    extend: 'Ext.data.Model',
    fields: ['id', 'name', 'email', 'phone']
});