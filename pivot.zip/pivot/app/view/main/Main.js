/**
 * This class is the main view for the application. It is specified in app.js as the
 * "mainView" property. That setting automatically applies the "viewport"
 * plugin causing this view to become the body element (i.e., the viewport).
 *
 * TODO - Replace this content of this view to suite the needs of your application.
 */

new Ext.util.KeyMap(document.body, {
    key: 'p',
    ctrl: true,
    fn: function (keycode, e) {
        e.stopEvent();

        console.log('ctrl + p was pressed');
    }
});
var store = Ext.create('UXDemo.store.productStore');
Ext.define('UXDemo.view.main.Main', {
    extend: 'Ext.grid.Panel',
    
    plugins: ['cellediting', 'gridfilters'],

    requires: [
        'UXDemo.view.main.MainController',
        'UXDemo.store.productStore',
    ],
    store: store,
    width: 600,
    title: 'Products',
    viewConfig: {
        getRowClass: function(record, rowIndex, rowParams, store){
            return record.get("phone").startsWith("1") ? "row-valid" : "row-error";
        }
    },
    columns: [
    {
        text: 'Id',
        dataIndex: 'id',
        hidden: true
    },
    {
        text: 'Name',
        width: 150,
        dataIndex: 'name',
       locked:true,
        filter: 'string',
        editor: {
            allowBlank: false,
            type: 'string'
        }
    },
    {
        text: 'Email',
        dataIndex: 'email',
        sortable: false,
        flex: 1,
        filter: {
            type: 'string',
            itemDefaults: { emptyText: 'Search for�' }
        }
    },
    {
        text: 'Phone',
        width: 100,
        dataIndex: 'phone',

    },
    {
        text: 'Role',
        width: 100,
        dataIndex: 'role',
        editor: new Ext.form.field.ComboBox({
            typeAhead: true,
            triggerAction: 'all',
            store: [
            ['Developer', 'Developer'],
            ['Manager', 'Manager'],
            ['SSE', 'SSE'],
            ['TL', 'TL'],
            ['PM', 'PM']
            ]
        })
    }
    ],

        dockedItems: [{
            xtype: 'pagingtoolbar',
            store: store,
            dock: 'bottom',
            displayInfo: true
        }]

});
