﻿Ext.define('UXDemo.store.productStore', {
    extend: 'Ext.data.Store',
    model: 'Product',
   
    autoLoad: true,
    proxy: {
        type: 'rest',
        url: 'https://jsonplaceholder.typicode.com/users',
        reader: {
            type: 'json',
            rootProperty: 'data',
            totalProperty: 'total'
        }
    }
    
});

