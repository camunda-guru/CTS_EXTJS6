﻿Ext.define('UXDemo.store.expenseStore', {
   

    extend: 'Ext.data.Store',
    alias: 'store.expense',
    storeId: 'expense',
    fields: [{name: 'employee', type: 'string',
        name: 'date', type: 'date', convert: function (v, record) {
            return Ext.Date.format(record.get('date'), "Y");
        }
    }, 'cat', 'spent',
    {
        name: 'year',
        convert: function (v, record) {
            return Ext.Date.format(record.get('date'), "Y");
        }
    }],
    data: {
        items: [
            { "employee":"Anoop","date": "1/1/2015", "cat": "Restaurant", "spent": 100 },
            { "employee": "Arjun", "date": "1/1/2015", "cat": "Travel", "spent": 22 },
            { "employee": "Swami", "date": "1/1/2015", "cat": "Insurance", "spent": 343 },
            { "employee": "Dany", "date": "1/1/2015", "cat": "Rent", "spent": 1000 },
            { "employee": "James", "date": "1/1/2015", "cat": "Groceries", "spent": 232 },
            { "employee": "Dravid", "date": "1/1/2015", "cat": "Utilities", "spent": 300 },

            { "employee": "Anoop", "date": "2/1/2015", "cat": "Restaurant", "spent": 2342 },
            { "employee": "Arjun", "date": "2/1/2015", "cat": "Travel", "spent": 150 },
            { "employee": "Swami", "date": "2/1/2015", "cat": "Insurance", "spent": 500 },
            { "employee": "Dany", "date": "2/1/2015", "cat": "Rent", "spent": 1000 },
            { "employee": "James", "date": "2/1/2015", "cat": "Groceries", "spent": 344 },
            { "employee": "Dravid", "date": "2/1/2015", "cat": "Utilities", "spent": 211 },

            { "employee": "Anoop", "date": "3/1/2015", "cat": "Restaurant", "spent": 100 },
            { "employee": "Anoop", "date": "3/1/2015", "cat": "Travel", "spent": 150 },
            { "employee": "Anoop", "date": "3/1/2015", "cat": "Insurance", "spent": 233 },
            { "employee": "Anoop", "date": "3/1/2015", "cat": "Rent", "spent": 1000 },
            { "employee": "Anoop", "date": "3/1/2015", "cat": "Groceries", "spent": 2342 },
            { "employee": "Anoop", "date": "3/1/2015", "cat": "Utilities", "spent": 533 },

            { "employee": "Anoop", "date": "4/1/2015", "cat": "Restaurant", "spent": 100 },
            { "employee": "Anoop", "date": "4/1/2015", "cat": "Travel", "spent": 150 },
            { "employee": "Anoop", "date": "4/1/2015", "cat": "Insurance", "spent": 234 },
            { "employee": "Anoop", "date": "4/1/2015", "cat": "Rent", "spent": 1000 },
            { "employee": "Anoop", "date": "4/1/2015", "cat": "Groceries", "spent": 400 },
            { "employee": "Anoop", "date": "4/1/2015", "cat": "Utilities", "spent": 34 },

            { "employee": "Anoop", "date": "5/1/2015", "cat": "Restaurant", "spent": 100 },
            { "employee": "Anoop", "date": "5/1/2015", "cat": "Travel", "spent": 150 },
            { "employee": "Anoop", "date": "5/1/2015", "cat": "Insurance", "spent": 600 },
            { "employee": "Anoop", "date": "5/1/2015", "cat": "Rent", "spent": 2345 },
            { "employee": "Anoop", "date": "5/1/2015", "cat": "Groceries", "spent": 234 },
            { "employee": "Anoop", "date": "5/1/2015", "cat": "Utilities", "spent": 344 },
        ]
    },
    proxy: {
        type: 'memory',
        reader: {
            type: 'json',
            rootProperty: 'items'
        }
    }
});


Ext.define('MyApp.model.ExpensebyMonth', {
    extend: 'Ext.data.Model',
    fields: [{ name: 'date', type: 'date' }, 'total']
});

Ext.define('MyApp.store.ExpensebyMonth', {
    extend: 'Ext.data.Store',
    alias: 'store.expensebyMonthStore',
    model: 'MyApp.model.ExpensebyMonth',
    data: (function () {
        var data = [];
        var expense = Ext.createByAlias('store.expense');
        expense.group('date');
        var groups = expense.getGroups();
        groups.each(function (group) {
            data.push({ date: group.config.groupKey, total: group.sum('spent') });
        });
        return data;
    })()
});