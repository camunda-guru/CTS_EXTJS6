﻿Ext.define('TouchEvents.view.media.Video', {
    extend: 'Ext.Container',
    requires: [
        'Ext.Video'
    ],
    layout: 'fit',
    shadow: true,
    listeners: {
        hide: function () {
            try {
                var video = this.down('video');
                video.fireEvent('hide');
            }
            catch (e) {
            }
        },
        show: function () {
            try {
                var video = this.down('video');
                video.fireEvent('show');
            }
            catch (e) {
            }
        }
    },
    items: [{
        xtype: 'video',
        url: ['Military Show_PSP.mp4'],
        loop: true,
        posterUrl: 'image1.jpg'
    }]
});