﻿Ext.define('D3Demo.view.main.TouchEvents', {
    extend: 'Ext.Container',
    xtype: 'touchevents',

    requires: [
        'D3Demo.view.main.touchevent.Info',
        'D3Demo.view.main.touchevent.Logger',
        'D3Demo.view.main.touchevent.Pad'
    ],


    initialize: function() {
        this.callParent(arguments);

        var padElement = Ext.get('touchpad'),
            fn = 'onTouchPadEvent';

        padElement.on({
            scope: this,
            touchstart: fn,
            touchend: fn,
            touchmove: fn,
            swipe: fn,
            dragstart: fn,
            drag: fn,
            dragend: fn,
            tap: fn,
            singletap: fn,
            doubletap: fn,
            longpress: fn,
            pinch: fn,
            rotate: fn
        });
    },

    onTouchPadEvent: function(e, target, options) {
        this.down('toucheventlogger').addLog(e.type);
    }
});