﻿Ext.define('TouchEvents.view.Carousel', {
    extend: 'Ext.Container',

    requires: [
        'Ext.carousel.Carousel'
    ],

    cls: 'cards',
    shadow: true,
    layout: {
        type: 'vbox',
        align: 'stretch',
        

    },
    defaults: {
        width:200,
        height:100,
        Style:{"background-color":"blue"}, 
        renderTo: document.body,
        flex: 1
    },
    items: [{
        xtype: 'carousel',
        items: [{
            html: '<p>Swipe left to show the next card…</p>',
            cls: 'card'
        },
        {
            html: '<p>You can also tap on either side of the indicators.</p>',
            cls: 'card'
        },
        {
            html: '<img src="image1.jpg">',
            cls: 'card'
        }]
    }, {
        xtype: 'carousel',
        ui: 'light',
        direction: 'vertical',
        items: [{
            html: 'Cards',
            cls: 'card dark'
        },
        {
            html: '<img src="modi.jpg">',
            cls: 'card dark'
        },
        {
            html: '<img src="watermark.png">',
            cls: 'card dark'
        }]
    }]
});